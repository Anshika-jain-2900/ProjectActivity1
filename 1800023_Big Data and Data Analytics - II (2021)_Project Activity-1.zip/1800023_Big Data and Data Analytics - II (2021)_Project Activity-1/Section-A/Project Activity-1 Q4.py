
#%%
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import calendar
from datetime import datetime
import seaborn as sns

bakery_dataset = pd.read_csv(r"BreadBasket_DMS.csv")
bakery_dataset.dropna()
bakery_dataset = bakery_dataset[bakery_dataset['Item'] != 'NONE']



bakery_dataset['Date'] = pd.to_datetime(bakery_dataset['Date'])
bakery_dataset['Weekday'] = bakery_dataset['Date'].dt.weekday
print("Five most popular items sold on Monday")
monday_info = bakery_dataset[bakery_dataset['Weekday'] == 0]
item, item_count = map_indexes_and_values(monday_info, 'Item')
plt.bar(item[:5], item_count[:5], color='y', label='Monday')
plt.xlabel('Popular items on Monday')
plt.ylabel('Number of Transactions')
plt.show()
print("5 most popular items sold on monday is:","\n", monday_info[:5])
#%%






